#pragma once

int static_lib_function(char* msg);
