#pragma once
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

int run_emergency_handler(int* pipe_fd);
